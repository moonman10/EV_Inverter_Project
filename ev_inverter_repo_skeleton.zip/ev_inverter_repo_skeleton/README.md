# EV Inverter Project (TI F280049C + DRV8320RS)

This repo contains hardware, software, and documentation for a student traction-inverter demo running sensorless FOC with safety features (brake chopper, CAN telemetry, fault handling).

## Structure
```
hardware/   # wiring, schematics, BOM, photos
software/   # CCS projects, config, scripts
notes/      # daily logs, experiments, plots
cad/        # 3D-printed mounts, guards, STEP/STL
docs/       # reports, diagrams, PDFs
scripts/    # Python (e.g., CAN logger, plotting)
safety.md   # safety plan & checklists
```
## Quick Start
1. Read `safety.md` (E‑Stop, fuse, one‑hand rule).  
2. Wire PSU(+) → **battery switch/E‑Stop** → **58 V MINI fuse** → **XT60(+)** → **VM(+)**. PSU(–) → **XT60(–)** → **GND**.  
3. Start at **24 V**, **2–3 A current limit**. No aggressive regen until the **brake chopper** is installed and tested.
4. In CCS import and run labs in order: `is01 → is02 → is05 → is06 → is07`.
5. Keep a daily log in `notes/` with photos/plots.

## Milestones
- M1: First power-up (no motor), offsets calibrated
- M2: Motor ID → clean Iq steps
- M3: Closed-loop speed
- M4: Brake chopper clamp verified
- M5: Encoder vs estimator comparison
- M6: Field-weakening curve
- M7: CAN telemetry + safety tests
