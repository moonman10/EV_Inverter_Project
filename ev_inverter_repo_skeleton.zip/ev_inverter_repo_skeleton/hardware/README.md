# hardware/

Add wiring photos, BOM, and schematics here.
